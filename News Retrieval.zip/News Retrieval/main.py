from asyncio import wait_for
from News_aggregator import NewsAggregator
from scrapy.crawler import CrawlerRunner
from News_Scraper import NewsSpider, collected_data
from Relevancy_computer import BM25Processor
from Summarizer import HeadlineSummarizer
from DocsRanker import DocRanker
import os
import warnings
from dotenv import dotenv_values
import pandas as pd

warnings.simplefilter("ignore")
warnings.filterwarnings("ignore", category=DeprecationWarning)

# @wait_for(100)
def run_news_spider(top_30_titles):
    """ run spider """
    crawler = CrawlerRunner()
    news_spider = crawler.crawl(NewsSpider, start_urls = [i["url"] for i in top_30_titles])
    return news_spider

def write_csv(df, file_name,drop_col):
  """ Function that creates a CSV File"""
  df.drop(drop_col, axis=1, inplace = True)
  df.to_csv(file_name , index=False)  

def scraped_content(url_to_scrape):
    """ This function scrapes for the content for required URLs"""
    news_articles = []
    for i in url_to_scrape:
        if i['url'] in collected_data.keys():
            news_articles.append({
                'title': i["title"],
                'publishedAt': i["publishedAt"],
                'url': i["url"],
                'description': collected_data[i["url"]]
            })
        else:
            news_articles.append({
                'title':i["title"],
                'publishedAt': i["publishedAt"],
                'url': i["url"],
                'description': i["description"],
            })

    return news_articles

if __name__ == "__main__":
    user_input = "Germany Attack"
    language = "en"

    config = dotenv_values(".env")
    open_ai_key = config["OPEN_AI_KEY"]
    news_api_key = config["NEWS_API_KEY"]
    news_dataio_key = config["NEWS_DATAIO_KEY"]

    news_aggregator = NewsAggregator(newsapi_key=news_api_key, newsDataIO_api_key=news_dataio_key)
    # news_aggregator = NewsAggregator(newsapi_key="a3fa0328296748b488d5306d8a81309e", newsDataIO_api_key="pub_45746beeb3c0cbd1d98c3349b4e31d7a95f9b")
    aggregated_news = news_aggregator.aggregate_news(user_input, language)
    write_csv(pd.DataFrame(aggregated_news), "All_news.csv","description")
    
    # for news in aggregated_news:
    #   print(f"Title: {news['title']}")
    #   break

    bm25_processor = BM25Processor(aggregated_news)
    top_30_titles = bm25_processor.get_top_titles(user_input, aggregated_news, n=30)

    # for news in top_30_titles:
    #   print(f"Title: {news['title']}")
    #   break
    
    print("Running spider")
    run_news_spider(top_30_titles)

    news_articles = scraped_content(top_30_titles)

    # for news in news_articles:
    #   print(news)
    #   break
      
    print("Ranking")
    doc_ranker = DocRanker()
    top_15_headlines = doc_ranker.get_top_headlines(user_input, news_articles)
    top_15_headlines.sort(key=lambda x: x['score'], reverse=True)

    for news in top_15_headlines:
      print(news)
      break

    write_csv(pd.DataFrame(top_15_headlines), "Top15_news.csv",["description","score"])

    print("Summarizing")
    gpt_headline_summarizer = HeadlineSummarizer(open_ai_key)
    summary = gpt_headline_summarizer.summarizing_headlines([i["title"] for i in top_15_headlines])
    print(summary)
    named_entities = gpt_headline_summarizer.extract_named_entities([i["title"] for i in top_15_headlines])
    print(named_entities)

    
    